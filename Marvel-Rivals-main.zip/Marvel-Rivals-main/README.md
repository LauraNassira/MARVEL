# 🃏 Marvel Rivals - Jogo de Cartas

**Marvel Rivals** é um jogo de cartas digital inspirado no universo Marvel, desenvolvido em HTML, CSS e JavaScript. O jogador escolhe entre dois decks temáticos — **Heróis** ou **Vilões** — e enfrenta o oponente em batalhas estratégicas até que todas as cartas de um dos lados sejam derrotadas.

## 🕹️ Como funciona o jogo

- O jogo começa com uma **tela de seleção de deck**, onde o jogador escolhe entre **Heróis** ou **Vilões**.
- Após a escolha, o deck selecionado é carregado automaticamente para a **tela de batalha**.
- Cada jogador possui uma **mão de cartas** visível no canto da tela:
  - Mão do jogador à esquerda (visível)
  - Mão do inimigo à direita (cartas viradas com imagem de verso)
- O campo de batalha fica no centro da tela, com animações ao jogar as cartas.

## ⚔️ Mecânicas principais

- **Cada carta possui:**
  - Imagem
  - Nome
  - Vida (HP)
  - Dois ataques diferentes (o jogador pode alternar entre eles)
- **Ao jogar uma carta:**
  - Ela sai da mão e aparece no campo, maior e com uma animação.
- **Combate:**
  - O jogador pode atacar com a carta em campo.
  - O HP da carta inimiga é reduzido com base no ataque escolhido.
  - Quando o HP de uma carta chega a **0**, ela é eliminada do campo.
- O inimigo joga automaticamente uma carta aleatória após a jogada do jogador.

## 🏆 Condição de vitória

- O jogo termina quando **todas as cartas de um dos jogadores são derrotadas**.
- O sistema exibe uma mensagem de **Vitória** ou **Derrota** ao final da partida.


## 🔇 Áudio

- Por enquanto, o jogo está **sem sons ativados**.

## 💻 Tecnologias utilizadas

- HTML5
- CSS3
- JavaScript (vanilla)

---

🎯 **Status:** Projeto em desenvolvimento  
🎮 **Objetivo:** Criar uma experiência interativa e divertida com personagens icônicos da Marvel, focando em lógica de jogo, manipulação de DOM e interação em tempo real.

